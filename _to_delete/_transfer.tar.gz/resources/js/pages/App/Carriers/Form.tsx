import { Link, useForm } from '@inertiajs/react'
import type { ReactNode } from 'react'
import { CheckboxField, SelectField, TextArea, TextField } from '@/components/Form/Field'
import { AppLayout } from '@/layouts/AppLayout'
import { useI18n } from '@/lib/i18n'

interface CarrierDetail {
  id: string
  legalName: string
  dba: string | null
  dotNumber: string
  mcNumber: string | null
  contact: string
  email: string
  phone: string
  website: string | null
  preferredLocale: string
  dispatchFeeBps: number
  usesFactoring: boolean
  notes: string | null
  physical: {
    line1: string | null
    line2: string | null
    city: string | null
    state: string | null
    postalCode: string | null
  }
}

interface Props {
  carrier: CarrierDetail | null
  canSetFee: boolean
}

/**
 * Alta y edición de un transportista.
 *
 * Un solo componente para las dos cosas porque los campos son idénticos; lo
 * único que cambia es el verbo y el destino. Duplicarlo garantizaría que dentro
 * de tres meses uno de los dos tenga un campo que el otro no.
 *
 * La tarifa de despacho se apaga cuando el usuario no puede cambiarla. Eso NO es
 * la defensa: el controlador descarta el campo aunque llegue en la petición. Es
 * cortesía, para que nadie escriba un número que va a desaparecer al guardar.
 */
export default function CarrierForm({ carrier, canSetFee }: Props) {
  const { t } = useI18n()
  const editing = carrier !== null

  const [firstName, ...restName] = (carrier?.contact ?? '').split(' ')

  const form = useForm({
    legal_name: carrier?.legalName ?? '',
    dba: carrier?.dba ?? '',
    dot_number: carrier?.dotNumber ?? '',
    mc_number: carrier?.mcNumber ?? '',
    contact_first_name: carrier ? (firstName ?? '') : '',
    contact_last_name: carrier ? restName.join(' ') : '',
    email: carrier?.email ?? '',
    phone: carrier?.phone ?? '',
    website: carrier?.website ?? '',
    preferred_locale: carrier?.preferredLocale ?? 'en',
    physical_line1: carrier?.physical.line1 ?? '',
    physical_line2: carrier?.physical.line2 ?? '',
    physical_city: carrier?.physical.city ?? '',
    physical_state: carrier?.physical.state ?? '',
    physical_postal_code: carrier?.physical.postalCode ?? '',
    // Puntos básicos, igual que la columna. El campo enseña el porcentaje y
    // convierte al escribir: el dinero se guarda en enteros para que no haya
    // redondeos, pero nadie escribe «1000» queriendo decir diez por ciento.
    //
    // Se guarda en bps y no en porcentaje porque así el nombre de la clave
    // coincide con el del servidor, y los errores de validación llegan al campo
    // correcto sin traducir nombres a mano.
    dispatch_fee_bps: carrier?.dispatchFeeBps ?? 1000,
    uses_factoring: carrier?.usesFactoring ?? false,
    notes: carrier?.notes ?? '',
  })

  const submit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editing) {
      form.patch(`/carriers/${carrier.id}`)
    } else {
      form.post('/carriers')
    }
  }

  return (
    <AppLayout
      title={t(editing ? 'carriers.form.editTitle' : 'carriers.form.createTitle')}
      description={t(editing ? 'carriers.form.editSubtitle' : 'carriers.form.createSubtitle')}
      crumbs={[
        { label: t('carriers.index.title'), href: '/carriers' },
        ...(editing
          ? [{ label: carrier.legalName, href: `/carriers/${carrier.id}` }]
          : []),
        { label: t(editing ? 'carriers.form.editTitle' : 'carriers.form.createTitle') },
      ]}
    >
      <form onSubmit={submit} className="flex max-w-3xl flex-col gap-6">
        <Section title={t('carriers.form.identity')}>
          <TextField
            label={t('carriers.form.legalName')}
            hint={t('carriers.form.legalNameHint')}
            required
            maxLength={200}
            value={form.data.legal_name}
            onChange={(e) => form.setData('legal_name', e.target.value)}
            error={form.errors.legal_name}
          />
          <TextField
            label={t('carriers.form.dba')}
            maxLength={200}
            value={form.data.dba}
            onChange={(e) => form.setData('dba', e.target.value)}
            error={form.errors.dba}
          />
          <TextField
            label={t('carriers.form.dotNumber')}
            hint={t('carriers.form.dotNumberHint')}
            required
            inputMode="numeric"
            maxLength={12}
            value={form.data.dot_number}
            onChange={(e) => form.setData('dot_number', e.target.value.replace(/\D/g, ''))}
            error={form.errors.dot_number}
          />
          <TextField
            label={t('carriers.form.mcNumber')}
            inputMode="numeric"
            maxLength={12}
            value={form.data.mc_number}
            onChange={(e) => form.setData('mc_number', e.target.value.replace(/\D/g, ''))}
            error={form.errors.mc_number}
          />
        </Section>

        <Section title={t('carriers.form.contact')}>
          <TextField
            label={t('carriers.form.firstName')}
            required
            maxLength={100}
            value={form.data.contact_first_name}
            onChange={(e) => form.setData('contact_first_name', e.target.value)}
            error={form.errors.contact_first_name}
          />
          <TextField
            label={t('carriers.form.lastName')}
            required
            maxLength={100}
            value={form.data.contact_last_name}
            onChange={(e) => form.setData('contact_last_name', e.target.value)}
            error={form.errors.contact_last_name}
          />
          <TextField
            label={t('carriers.form.email')}
            type="email"
            required
            maxLength={255}
            value={form.data.email}
            onChange={(e) => form.setData('email', e.target.value)}
            error={form.errors.email}
          />
          <TextField
            label={t('carriers.form.phone')}
            type="tel"
            required
            maxLength={32}
            value={form.data.phone}
            onChange={(e) => form.setData('phone', e.target.value)}
            error={form.errors.phone}
          />
          <TextField
            label={t('carriers.form.website')}
            type="url"
            maxLength={255}
            placeholder="https://"
            value={form.data.website}
            onChange={(e) => form.setData('website', e.target.value)}
            error={form.errors.website}
          />
          <SelectField
            label={t('carriers.form.preferredLocale')}
            hint={t('carriers.form.preferredLocaleHint')}
            required
            value={form.data.preferred_locale}
            onChange={(e) => form.setData('preferred_locale', e.target.value)}
            options={[
              { value: 'en', label: 'English' },
              { value: 'es', label: 'Español' },
            ]}
            error={form.errors.preferred_locale}
          />
        </Section>

        <Section title={t('carriers.form.address')}>
          <div className="sm:col-span-2">
            <TextField
              label={t('carriers.form.line1')}
              maxLength={200}
              value={form.data.physical_line1}
              onChange={(e) => form.setData('physical_line1', e.target.value)}
              error={form.errors.physical_line1}
            />
          </div>
          <TextField
            label={t('carriers.form.line2')}
            maxLength={200}
            value={form.data.physical_line2}
            onChange={(e) => form.setData('physical_line2', e.target.value)}
            error={form.errors.physical_line2}
          />
          <TextField
            label={t('carriers.form.city')}
            maxLength={120}
            value={form.data.physical_city}
            onChange={(e) => form.setData('physical_city', e.target.value)}
            error={form.errors.physical_city}
          />
          <TextField
            label={t('carriers.form.state')}
            maxLength={2}
            value={form.data.physical_state}
            onChange={(e) => form.setData('physical_state', e.target.value.toUpperCase())}
            error={form.errors.physical_state}
          />
          <TextField
            label={t('carriers.form.postalCode')}
            maxLength={12}
            value={form.data.physical_postal_code}
            onChange={(e) => form.setData('physical_postal_code', e.target.value)}
            error={form.errors.physical_postal_code}
          />
        </Section>

        <Section title={t('carriers.form.commercial')}>
          <TextField
            label={t('carriers.form.dispatchFee')}
            hint={canSetFee ? t('carriers.form.dispatchFeeHint') : t('carriers.form.dispatchFeeLocked')}
            type="number"
            min={0}
            max={100}
            step={0.25}
            disabled={!canSetFee}
            value={form.data.dispatch_fee_bps / 100}
            onChange={(e) =>
              form.setData('dispatch_fee_bps', Math.round(Number(e.target.value || 0) * 100))
            }
            error={form.errors.dispatch_fee_bps}
          />
          <div className="self-end">
            <CheckboxField
              label={t('carriers.form.usesFactoring')}
              checked={form.data.uses_factoring}
              onChange={(e) => form.setData('uses_factoring', e.target.checked)}
            />
          </div>
          <div className="sm:col-span-2">
            <TextArea
              label={t('carriers.form.notes')}
              hint={t('carriers.form.notesHint')}
              maxLength={5000}
              value={form.data.notes}
              onChange={(e) => form.setData('notes', e.target.value)}
              error={form.errors.notes}
            />
          </div>
        </Section>

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={form.processing}
            className="rounded bg-safety-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-safety-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {form.processing
              ? t('common.states.saving')
              : t(editing ? 'carriers.form.saveChanges' : 'carriers.form.save')}
          </button>
          <Link
            href={editing ? `/carriers/${carrier.id}` : '/carriers'}
            className="rounded border border-steel-300 px-4 py-2.5 text-sm font-medium text-navy-700 transition hover:bg-navy-50"
          >
            {t('carriers.form.cancel')}
          </Link>
        </div>
      </form>
    </AppLayout>
  )
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="rounded border border-steel-200 bg-white p-5">
      <legend className="px-1 text-xs font-bold uppercase tracking-[0.12em] text-safety-600">
        {title}
      </legend>
      <div className="mt-2 grid gap-4 sm:grid-cols-2">{children}</div>
    </fieldset>
  )
}

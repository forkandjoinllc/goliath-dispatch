import Link from 'next/link'
import { notFound } from 'next/navigation'
import { isLocale } from '@/i18n/config'
import { getDictionary } from '@/i18n/dictionary'
import { createTranslator } from '@/i18n/translate'
import { loadFor } from '@/server/action'
import { getTenantPolicy } from '@/server/context'
import { can, scopeFilter } from '@/lib/permissions'
import { listTrucks } from '@/server/equipment/queries'
import { PageHeader } from '@/components/shell/page-header'
import { Button } from '@/components/ui/button'
import { EquipmentList } from '../_components/equipment-list'

export default async function TrucksPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>
  searchParams: Promise<{ page?: string; pageSize?: string; search?: string; status?: string }>
}) {
  const { locale } = await params
  if (!isLocale(locale)) notFound()
  const query = await searchParams

  const ctx = await loadFor('equipment:read')
  const dictionary = await getDictionary(locale, ['equipment', 'common'])
  const t = createTranslator(dictionary, locale)

  const policy = await getTenantPolicy(ctx.actor.tenantId)
  const decision = can(ctx.actor, 'equipment:read', undefined, policy)
  const scope = scopeFilter(ctx.actor, decision.scope!)
  const canCreate = can(ctx.actor, 'equipment:create', undefined, policy).allowed

  const page = Math.max(1, Number(query.page) || 1)
  const pageSize = Math.min(200, Math.max(1, Number(query.pageSize) || 25))
  const search = query.search ?? ''
  const status = query.status ?? ''

  const result = await listTrucks(ctx.db, scope, {
    search: search || undefined,
    status: (status || undefined) as never,
    pagination: { page, pageSize },
  })

  return (
    <div className="space-y-6">
      <PageHeader
        title={t('equipment.trucks.title')}
        primaryAction={
          canCreate ? (
            <Button asChild>
              <Link href={`/${locale}/app/equipment/trucks/new`}>{t('equipment.trucks.new')}</Link>
            </Button>
          ) : undefined
        }
      />
      <EquipmentList
        locale={locale}
        equipmentType="truck"
        rows={result.rows}
        total={result.total}
        page={page}
        pageSize={pageSize}
        search={search}
        status={status}
      />
    </div>
  )
}

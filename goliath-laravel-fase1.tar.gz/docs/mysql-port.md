# Port de PostgreSQL a MySQL 8.0

Mapeo autoritativo para la migración de Goliath Dispatch de PostgreSQL/Drizzle a
MySQL/Eloquent. Cada regla de aquí fue **verificada ejecutándola** contra MySQL
8.0.46, no inferida de la documentación.

## Resumen de la verificación

| Característica PostgreSQL | Reemplazo en MySQL | Verificado |
|---|---|---|
| `pgEnum` | `varchar` + `CHECK (col IN (...))` | Acepta válidos, rechaza inventados |
| `JSONB` | `JSON` | Extracción con `json_extract` funciona |
| `timestamptz` | `datetime(3)` en UTC | Ver §Fechas |
| Índice único parcial | Columna generada `STORED` + índice único | Semántica completa, incluido soft delete |
| Trigger plpgsql genérico | Trigger explícito por tabla con `SIGNAL` | `UPDATE`/`DELETE` rechazados |
| `FOR UPDATE SKIP LOCKED` | Idéntico | Soportado en 8.0 |
| `uuid` | `char(36)` | Ver §Claves |

## Requisito de versión

**MySQL 8.0.16 o superior.** Antes de esa versión MySQL *acepta* la sintaxis
`CHECK` y la ignora silenciosamente, lo que convertiría cada restricción de enum
y cada guarda de dinero no negativo en decoración. Forge instala 8.0 por
defecto; el servidor `fleetforce` corre 8.0.46.

## Claves

`char(36)` con UUID v4, mediante el trait `HasUuids` de Laravel.

`binary(16)` sería un 55% más compacto y produciría índices más rápidos, pero
vuelve ilegible cualquier consulta manual, cualquier volcado y cualquier línea
de log — y en un sistema donde la depuración pasa por leer una pista de
auditoría, esa legibilidad vale más que los bytes.

Toda tabla propiedad de un tenant lleva además:

```sql
unique key <tabla>_tenant_id_uq (tenant_id, id)
```

No es redundante con la primaria: es lo que permite que un hijo referencie
`(tenant_id, id)` del padre y que el trigger de guarda pueda comparar.

## Fechas

**`datetime(3)`, siempre en UTC. Nunca `timestamp`.**

Laravel genera columnas `timestamp` con `$table->timestamps()`. En MySQL el tipo
`timestamp` se agota en **2038-01-19**. Este sistema guarda registros
financieros con retención de siete años, permisos con fecha de vencimiento y
citas de entrega programadas a futuro; una fecha de 2039 es un dato normal, no
un caso extremo. Por eso las migraciones declaran las columnas de fecha
explícitamente:

```php
$table->dateTime('created_at', 3)->useCurrent();
$table->dateTime('updated_at', 3)->useCurrent()->useCurrentOnUpdate();
```

MySQL no tiene equivalente de `timestamptz`: no guarda la zona. La aplicación
almacena UTC y resuelve la zona al presentar. Esto importa especialmente en las
paradas de carga, donde la cita se muestra en la zona local de la instalación y
no en la del tenant.

## Dinero

`bigint` **con signo**, en centavos.

Sin signo sería tentador, pero el margen bruto y la liquidación neta pueden ser
legítimamente negativos: una carga que se vendió por debajo del costo, o un
transportista cuyas deducciones exceden su tarifa. Las restricciones
`CHECK (col >= 0)` se aplican solo donde el valor no puede ser negativo por
definición — el cargo al cliente, la tarifa bruta, el monto de un gasto.

Los porcentajes son puntos base (`int`), con `CHECK (col BETWEEN 0 AND 10000)`.

## Enumeraciones

`varchar(n)` con una restricción `CHECK`, más un enum de PHP como fuente de
verdad en la aplicación y un cast de Eloquent.

MySQL tiene un tipo `ENUM` nativo, pero agregarle un valor requiere reescribir
la tabla (`ALTER TABLE ... MODIFY COLUMN`), que sobre una tabla de cargas grande
significa bloqueo y minutos de espera. Con `varchar` + `CHECK`, agregar un
estado es soltar y recrear una restricción: instantáneo.

## Colaciones

El esquema usa `utf8mb4_0900_ai_ci` por defecto — insensible a mayúsculas y
acentos, correcto para nombres de empresas y búsquedas de texto.

**Excepción:** las columnas que guardan hashes, tokens y huellas digitales se
declaran `char(64) charset ascii collate ascii_bin`. Son hexadecimal, así que
`ascii` basta, y `_bin` las hace sensibles a mayúsculas — una colación `ai_ci`
trataría dos hashes que difieren solo en el caso como el mismo valor, lo que en
un índice único de tokens de sesión sería un defecto de seguridad, no una
comodidad.

## Índices únicos parciales

PostgreSQL permite `unique index ... where <predicado>`. MySQL no. El reemplazo
es una columna generada que vale `NULL` cuando el predicado no se cumple —y
MySQL no considera los `NULL` como duplicados— más un índice único sobre ella:

```sql
primary_contact_key char(36) as (
  case when is_primary = 1 and deleted_at is null then customer_id end
) stored,
unique key customer_contacts_primary_uq (primary_contact_key)
```

Verificado: acepta el primer principal, rechaza el segundo del mismo cliente,
permite cuantos no-principales haga falta, y libera el hueco cuando el
principal se borra en suave.

`STORED` y no `VIRTUAL`: un índice único sobre una columna virtual funciona,
pero se recalcula en cada lectura del índice, y esta se consulta en cada
escritura de contacto.

## Triggers

Dos familias, ambas con `SIGNAL SQLSTATE '45000'`.

**Inmutabilidad append-only** para `audit_events`, `signature_audit_events`,
`load_status_history` y `financial_snapshots`. En PostgreSQL era una única
función plpgsql aplicada en bucle sobre una lista de tablas. MySQL no permite
SQL dinámico dentro de un trigger, así que cada tabla lleva su par explícito
`before update` / `before delete`. Más verboso; misma garantía.

**Guardas de aislamiento entre empresas** en cada relación hijo→padre de riesgo:
el trigger lee el `tenant_id` del padre y aborta si no coincide. Es la segunda
línea de defensa, después del scope global de Eloquent y antes de la revisión de
código.

En las migraciones se aplican con `DB::unprepared()`, que acepta el bloque
`BEGIN ... END` completo como una sola sentencia. `DELIMITER` es un comando del
cliente `mysql` y no existe vía PDO.

## Lo que se pierde

Honestamente, tres cosas:

1. **`CHECK` con subconsultas.** PostgreSQL tampoco las permite, pero sus
   constraints de exclusión sí resolvían el solapamiento de compromisos de
   equipo. En MySQL la detección de conflictos de horario queda enteramente en
   la capa de aplicación, respaldada por pruebas.
2. **Índices `GIN` sobre JSON.** MySQL indexa JSON solo a través de columnas
   generadas. Donde había búsqueda sobre `jsonb`, ahora hay una columna
   generada explícita e indexada.
3. **Transacciones DDL.** PostgreSQL puede revertir un `ALTER TABLE`; MySQL no.
   Una migración que falla a mitad deja el esquema a medias, así que las
   migraciones se escriben cortas y con un `down()` que realmente revierte.
